require("awful.util").deprecate("Use beautiful.theme_assets instead.")
return require("beautiful.theme_assets")
